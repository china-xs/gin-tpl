package route



import (
	apiAccountV1 "github.com/china-xs/gin-cms/api/account/v1"
	impl "github.com/china-xs/gin-cms/internal/service/account/v1"
	tpl "github.com/china-xs/gin-tpl"
	"github.com/google/wire"
)

//var Provider = wire.NewSet(NewRoute, NewOptions)

//wire.NewSet
var ProviderSet = wire.NewSet(wire.Struct(new(Route), "*"))

type Route struct {
	Accountv1 *impl.AccountService
}

func (r Route) InitRoute(app *tpl.Server) (*tpl.Server, error) {
	apiAccountV1.RegisterAccountGinServer(app,r.Accountv1)
	return app, nil
}
