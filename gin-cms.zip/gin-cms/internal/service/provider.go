package service

import (
	v1Account "github.com/china-xs/gin-cms/internal/service/account/v1"
	"github.com/google/wire"
)

var ProviderSet = wire.NewSet(
	v1Account.NewAccountService,
)