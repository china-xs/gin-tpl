//go:build wireinject
// +build wireinject

package main

import (
	"github.com/china-xs/gin-cms/internal/route"
	"github.com/china-xs/gin-cms/internal/service"
	tpl "github.com/china-xs/gin-tpl"
	"github.com/china-xs/gin-tpl/pkg/db"
	"github.com/china-xs/gin-tpl/pkg/log"
	"github.com/china-xs/gin-tpl/pkg/redis"

	//tpl "github.com/china-xs/gin-tpl"
	"github.com/china-xs/gin-tpl/pkg/config"
	"github.com/google/wire"
)

var providerSet = wire.NewSet(
	log.ProviderSet,
	db.ProviderSet,
	redis.ProviderSet,
	config.ProviderSet,
	service.ProviderSet,
	route.ProviderSet,
)

// cf config path
func initApp(path string) (*tpl.Server, func(), error) {
	panic(wire.Build(
		providerSet,
		newApp))
}
